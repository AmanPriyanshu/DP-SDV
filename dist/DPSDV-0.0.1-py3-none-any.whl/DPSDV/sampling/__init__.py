"""SDV Sampling module."""

from DPSDV.sampling.tabular import Condition

__all__ = [
    'Condition',
]
