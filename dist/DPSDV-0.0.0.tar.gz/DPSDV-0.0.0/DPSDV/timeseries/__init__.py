"""Models for timeseries data."""

from DPSDV.timeseries.deepecho import PAR

__all__ = (
    'PAR',
)
