"""Relational models subpackage."""

from DPSDV.relational.hma import HMA1

__all__ = (
    'HMA1',
)
