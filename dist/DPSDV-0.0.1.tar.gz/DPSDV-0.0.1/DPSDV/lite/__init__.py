"""SDV lite package that contains model presets."""

from DPSDV.lite.tabular import TabularPreset

__all__ = (
    'TabularPreset',
)
